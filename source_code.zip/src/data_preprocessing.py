
"""data_preprocessing.py
Loads raw CSVs, cleans data, and saves a cleaned CSV for downstream tasks.
"""
import pandas as pd
import numpy as np
import os

def load_and_concat(paths):
    dfs = [pd.read_csv(p, low_memory=False) for p in paths]
    combined = pd.concat(dfs, ignore_index=True, sort=False)
    combined.columns = [c.strip().lower().replace(' ', '_') for c in combined.columns]
    return combined

def parse_dates(df, date_cols=None):
    if date_cols is None:
        date_cols = [c for c in df.columns if 'date' in c or 'time' in c or 'timestamp' in c]
    if date_cols:
        df['date_parsed'] = pd.to_datetime(df[date_cols[0]], errors='coerce')
    else:
        df['date_parsed'] = pd.NaT
    return df

def impute_numeric_with_median(df):
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    for col in numeric_cols:
        median_val = df[col].median(skipna=True)
        if not pd.isna(median_val):
            df[col] = df[col].fillna(median_val)
    return df

def create_cleaned_csv(input_paths, output_path):
    df = load_and_concat(input_paths)
    df = parse_dates(df)
    df = impute_numeric_with_median(df)
    df = df.drop_duplicates()
    df.to_csv(output_path, index=False)
    print(f"Saved cleaned CSV to {output_path}")

if __name__ == '__main__':
    # Example usage (adjust paths as needed)
    inputs = ["/mnt/data/coin_gecko_2022-03-16.csv", "/mnt/data/coin_gecko_2022-03-17.csv"]
    out = "/mnt/data/submission_package/cleaned_crypto_for_submission.csv"
    create_cleaned_csv(inputs, out)
