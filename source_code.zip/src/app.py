
"""app.py
Streamlit app skeleton to load model and make predictions.
Run: streamlit run app.py
"""
import streamlit as st
import pandas as pd, joblib, os

st.title('Cryptocurrency Liquidity Predictor - Demo')

model_path = '/mnt/data/submission_package/models/rf_model.joblib'
if os.path.exists(model_path):
    model = joblib.load(model_path)
    st.success('Loaded model')
else:
    st.warning('Model not found. Run model_training.py first.')

uploaded = st.file_uploader('Upload CSV (cleaned_with_features.csv)', type=['csv'])
if uploaded is not None:
    df = pd.read_csv(uploaded)
    st.dataframe(df.head())
    if st.button('Predict (demo)'):
        feat_cols = [c for c in ['price','24h_volume','mkt_cap','price_change_pct','log_return','volume_ma_7','volume_ma_30','volatility_7'] if c in df.columns]
        X = df[feat_cols].fillna(df[feat_cols].median())
        preds = model.predict(X)
        df['predicted_liquidity_ratio'] = preds
        st.line_chart(df['predicted_liquidity_ratio'])
