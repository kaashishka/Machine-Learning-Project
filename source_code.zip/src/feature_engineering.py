
"""feature_engineering.py
Creates liquidity-related features and saves enhanced dataset.
"""
import pandas as pd
import numpy as np

def add_features(df):
    # ensure date parsed
    if 'date_parsed' not in df.columns and 'date' in df.columns:
        df['date_parsed'] = pd.to_datetime(df['date'], errors='coerce')
    id_col = 'symbol' if 'symbol' in df.columns else df.columns[0]
    df = df.sort_values([id_col, 'date_parsed'])
    if 'price' in df.columns:
        df['price_prev'] = df.groupby(id_col)['price'].shift(1)
        df['price_change_pct'] = (df['price'] - df['price_prev']) / df['price_prev']
        df['log_return'] = np.log(df['price']).diff()
        df['log_return'] = df['log_return'].fillna(0)
    vol_col = None
    for c in ['24h_volume','total_volume','volume']:
        if c in df.columns:
            vol_col = c; break
    if vol_col:
        df['volume_ma_7'] = df.groupby(id_col)[vol_col].transform(lambda x: x.rolling(window=7, min_periods=1).mean())
        df['volume_ma_30'] = df.groupby(id_col)[vol_col].transform(lambda x: x.rolling(window=30, min_periods=1).mean())
    if vol_col and 'mkt_cap' in df.columns:
        df['liquidity_ratio'] = df[vol_col] / df['mkt_cap']
    else:
        df['liquidity_ratio'] = np.nan
    return df

if __name__ == '__main__':
    path = "/mnt/data/submission_package/cleaned_crypto_for_submission.csv"
    df = pd.read_csv(path, low_memory=False, parse_dates=['date_parsed'])
    df2 = add_features(df)
    df2.to_csv('/mnt/data/submission_package/cleaned_with_features.csv', index=False)
    print('Saved cleaned_with_features.csv')
