
"""eda.py
Produces exploratory data analysis outputs: summary stats and plots.
"""
import pandas as pd
import matplotlib.pyplot as plt
import os

def load_cleaned(path):
    return pd.read_csv(path, low_memory=False, parse_dates=['date_parsed'], infer_datetime_format=True)

def summary_stats(df, cols, out_path):
    stats = df[cols].describe().transpose()
    stats.to_csv(out_path)
    print(f"Saved summary stats to {out_path}")
    return stats

def plot_price_top_coins(df, price_col='price', mkt_cap_col='mkt_cap', out_dir='plots'):
    os.makedirs(out_dir, exist_ok=True)
    if mkt_cap_col in df.columns:
        latest = df.sort_values('date_parsed').groupby(df.get('symbol', df.columns[0])).last().reset_index()
        top = latest.sort_values(mkt_cap_col, ascending=False).head(3)
        top_symbols = top['symbol'].tolist()
    else:
        top_symbols = df['symbol'].unique()[:3].tolist()
    for s in top_symbols:
        sub = df[df['symbol'] == s].sort_values('date_parsed')
        plt.figure(figsize=(8,3))
        plt.plot(sub['date_parsed'], sub[price_col])
        plt.title(f"{s} - {price_col} over time")
        plt.tight_layout()
        fpath = os.path.join(out_dir, f"price_{s}.png")
        plt.savefig(fpath)
        plt.close()
        print(f"Saved plot: {fpath}")

if __name__ == '__main__':
    cleaned = "/mnt/data/submission_package/cleaned_crypto_for_submission.csv"
    df = load_cleaned(cleaned)
    cols = [c for c in ['price','24h_volume','mkt_cap'] if c in df.columns]
    summary_stats(df, cols, "/mnt/data/submission_package/eda_summary_stats.csv")
    plot_price_top_coins(df, out_dir='/mnt/data/submission_package/plots')
