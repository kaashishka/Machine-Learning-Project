
"""model_training.py
Train baseline models and save best model.
"""
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
import os

def train_models(df, target='liquidity_ratio', features=None):
    df = df.dropna(subset=[target]).copy()
    if features is None:
        features = [c for c in ['price','24h_volume','mkt_cap','price_change_pct','log_return','volume_ma_7','volume_ma_30','volatility_7'] if c in df.columns]
    df = df.sort_values('date_parsed')
    split = int(0.8*len(df))
    train = df.iloc[:split]; test = df.iloc[split:]
    X_train = train[features].fillna(train[features].median())
    y_train = train[target]
    X_test = test[features].fillna(train[features].median())
    y_test = test[target]
    lr = LinearRegression().fit(X_train, y_train)
    rf = RandomForestRegressor(n_estimators=100, random_state=42).fit(X_train, y_train)
    # evaluate
    def evalm(m, X, y):
        p = m.predict(X)
        return {'rmse': np.sqrt(mean_squared_error(y,p)), 'mae': mean_absolute_error(y,p), 'r2': r2_score(y,p)}
    res = {'lr': evalm(lr, X_test, y_test), 'rf': evalm(rf, X_test, y_test)}
    # save RF model
    os.makedirs('/mnt/data/submission_package/models', exist_ok=True)
    joblib.dump(rf, '/mnt/data/submission_package/models/rf_model.joblib')
    return res

if __name__ == '__main__':
    df = pd.read_csv('/mnt/data/submission_package/cleaned_with_features.csv', parse_dates=['date_parsed'], low_memory=False)
    results = train_models(df)
    print(results)
